package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.calculator.R;

public class MainActivity extends AppCompatActivity {
    TextView primaryText, secondaryText;
    String number1, number2, operator;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        primaryText = findViewById(R.id.primaryTextviewID);
        secondaryText = findViewById(R.id.secondaryTextviewID);
    }

    public void numberFunction(View view) {
        String primaryValue = primaryText.getText().toString();
        if (primaryValue.equals("0")) {
            if (view.getId() == R.id.btnZeroID) {
                primaryText.setText("0");
            } else if (view.getId() == R.id.btnOneID) {
                primaryText.setText("1");
            } else if (view.getId() == R.id.btnTwoID) {
                primaryText.setText("2");
            } else if (view.getId() == R.id.btnThreeID) {
                primaryText.setText("3");
            } else if (view.getId() == R.id.btnFourID) {
                primaryText.setText("4");
            } else if (view.getId() == R.id.btnFiveID) {
                primaryText.setText("5");
            } else if (view.getId() == R.id.btnSixID) {
                primaryText.setText("6");
            } else if (view.getId() == R.id.btnSevenID) {
                primaryText.setText("7");
            } else if (view.getId() == R.id.btnEightID) {
                primaryText.setText("8");
            } else {
                primaryText.setText("9");
            }
        } else {
            if (view.getId() == R.id.btnZeroID) {
                primaryText.setText(primaryValue + "0");
            } else if (view.getId() == R.id.btnOneID) {
                primaryText.setText(primaryValue + "1");
            } else if (view.getId() == R.id.btnTwoID) {
                primaryText.setText(primaryValue + "2");
            } else if (view.getId() == R.id.btnThreeID) {
                primaryText.setText(primaryValue + "3");
            } else if (view.getId() == R.id.btnFourID) {
                primaryText.setText(primaryValue + "4");
            } else if (view.getId() == R.id.btnFiveID) {
                primaryText.setText(primaryValue + "5");
            } else if (view.getId() == R.id.btnSixID) {
                primaryText.setText(primaryValue + "6");
            } else if (view.getId() == R.id.btnSevenID) {
                primaryText.setText(primaryValue + "7");
            } else if (view.getId() == R.id.btnEightID) {
                primaryText.setText(primaryValue + "8");
            } else {
                primaryText.setText(primaryValue + "9");
            }
        }


    }

    public void clearFunction(View view) {
        primaryText.setText("0");
        secondaryText.setText("");

    }

    public void clear2(View view) {
        primaryText.setText("0");
    }

    public void operatorFunction(View view) {
        if (view.getId() == R.id.btnMultiplyID) {
            operator = "*";
        } else if (view.getId() == R.id.btnMinusID) {
            operator = "-";
        } else if (view.getId() == R.id.btnPlusID) {
            operator = "+";
        } else {
            operator = "/";
        }
        String primaryValue = primaryText.getText().toString();
        secondaryText.setText(primaryValue + " " + operator);
        number1 = primaryValue;
        primaryText.setText("0");
    }

    public void resultFunction(View view) {
        number2 = primaryText.getText().toString();
        double result;
        if (operator.equals("+")) {
            result = Double.parseDouble(number1) + Double.parseDouble(number2);
        } else if (operator.equals("-")) {
            result = Double.parseDouble(number1) - Double.parseDouble(number2);
        } else if (operator.equals("*")) {
            result = Double.parseDouble(number1) * Double.parseDouble(number2);
        } else {
            result = Double.parseDouble(number1) / Double.parseDouble(number2);
        }
        secondaryText.setText(number1 + operator + number2 + "=");
        primaryText.setText("" + result);

    }

    public void factorialFunction(View view) {
        String primaryValue = primaryText.getText().toString();
        if (!primaryValue.contains(".")) {
            primaryText.setText(primaryValue + ".");
        }
    }

    public void reverseFunction(View view) {
        String primaryValue = primaryText.getText().toString();
        primaryText.setText("-" + primaryValue);
    }


    public void squareFunction(View view) {
        number1 = primaryText.getText().toString();
        double result;
        if (view.getId() == R.id.btnXSquareID) {
            result = Double.parseDouble(number1) * Double.parseDouble(number1);
            secondaryText.setText("sqr" + (number1));
            primaryText.setText("" + result);
        }
    }

    public void divisionFunction(View view) {
        number1 = primaryText.getText().toString();
        double result;
        if (view.getId() == R.id.btnOneByXID) {
            result = 1 / Double.parseDouble(number1);
            secondaryText.setText("1" +"/" + (number1));
            primaryText.setText("" + result);
        }
    }


    public void modFunction(View view) {
        number1 = primaryText.getText().toString();
        number2 = primaryText.getText().toString();
        if (view.getId() == R.id.btnPercentageID) {
            double result = Double.parseDouble(number1) % Double.parseDouble(number1);
            secondaryText.setText(number1 + operator + number2 );
            primaryText.setText("" + result);
        }
    }
}